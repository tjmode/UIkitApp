//
//  BodyCollectionViewCell.swift
//  InShorts Clone
//
//  Created by Sunitha Balasubramanian on 01/09/20.
//  Copyright © 2020 Sunitha Balasubramanian. All rights reserved.
//

import UIKit

class BodyCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var bodyImage: UIImageView!
    
    @IBOutlet weak var bodyLabel: UILabel!
}
