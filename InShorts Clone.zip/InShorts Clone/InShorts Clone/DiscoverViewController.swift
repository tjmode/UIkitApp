//
//  DiscoverViewController.swift
//  InShorts Clone
//
//  Created by Sunitha Balasubramanian on 29/08/20.
//  Copyright © 2020 Sunitha Balasubramanian. All rights reserved.
//

import UIKit

class DiscoverViewController: UIViewController {
    
    @IBOutlet weak var masterCollectionView: UICollectionView!
    
    
    var sampleItems = ["Hello", "Dont care"]

    override func viewDidLoad() {
        super.viewDidLoad()
        masterCollectionView.dataSource = self
        masterCollectionView.delegate = self
        navigationController?.isNavigationBarHidden = false
        title = "Discover"
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "gear"), style: .plain, target: self, action: nil)
        
        let myFeedButton = UIBarButtonItem(title: "My Feed", style: .done, target: self, action: #selector(backToNewsFeed))
        let backbutton = UIBarButtonItem(image: UIImage(systemName: "chevron.right"), style: .plain, target: self, action: #selector(backToNewsFeed))
        navigationItem.rightBarButtonItems = [backbutton, myFeedButton]
        
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension DiscoverViewController:  UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "masterCell", for: indexPath) as! DiscoverCollectionViewCell
        cell.setup()
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: view.frame.size.width, height: 1500)
    }
    
    @objc func backToNewsFeed() {
        let viewController = self.storyboard!.instantiateViewController(identifier: "mainVC") as! ViewController
        self.navigationController!.pushViewController(viewController, animated: true)
    }
    
}
