//
//  FooterCollectionViewCell.swift
//  InShorts Clone
//
//  Created by Tonywilson Jesuraj on 02/09/20.
//  Copyright © 2020 Sunitha Balasubramanian. All rights reserved.
//

import UIKit

class FooterCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var footerImageView: UIImageView!
    
    @IBOutlet weak var FooterLabel: UILabel!
    
}
